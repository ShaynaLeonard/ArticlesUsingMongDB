// Import required modules
const express = require('express');
const Article = require('../models/article');
const Review = require('../models/review');
const router = new express.Router();

module.exports = router;
